# PRACTICE ONLY 2020-24. Uses Taskforce panel.parquet (story_q.py/score.py conventions): entry=open of D,
# exit=open of D+h (h=5/10/21 bars), net = gross-0.006 (30bp/side), win = net>0. Features use bars < D.
import numpy as np, pandas as pd, pyarrow.parquet as pq, hashlib, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
SEED=20261022; HI=pd.Timestamp("2024-12-31"); H=(5,10,21)
PX="/workspace/pricehist/universe_2020_survivors.parquet"
assert hashlib.sha256(open(PX,"rb").read()).hexdigest().startswith("fb9bbe69")
M=pd.read_parquet("/workspace/state_test/story_q/panel.parquet"); assert M.date.max()<=HI
CP=[c for c in M.columns if c.startswith("cp_")]; HARD=CP[:6]
M["A"]=(M[HARD].values==2).all(1)
for h in H: M[f"x{h}"]=M[f"r{h}"]-M.groupby("date")[f"r{h}"].transform("mean")
RULES={"R1_chart_pass":M.A,"R2_chart_pass_Q5":M.A&M.sq5_big_red_recent,
 "R3_chart_pass_Q7":M.A&M.sq7_lowerbb_reclaim,"R4_chart_pass_Q8_FADE":M.A&M.sq8_above_last_red_high}
QCOLS=CP+[c for c in M.columns if c.startswith("sq") and c!="sq_ready"]
rng=np.random.default_rng(SEED); summ=[]; picks={}
for name,m in RULES.items():
    S=M.loc[m,["ticker","date"]+QCOLS+["r5","r10","r21","x5","x10","x21"]].copy()
    for h in H: S[f"win{h}"]=np.where(S[f"r{h}"].isna(),"",np.where(S[f"r{h}"]>0,"WIN","LOSE"))
    S.to_csv(f"{name}_cases.csv.gz",index=False)
    for h in H:
        s=S[f"r{h}"].dropna(); x=S[f"x{h}"].dropna()
        summ.append(dict(rule=name,h=h,n=len(s),win_pct=round((s>0).mean()*100,1),mean_net_pct=round(s.mean()*100,2),
          median_net_pct=round(s.median()*100,2),excess_vs_sameday_all_pct=round(x.mean()*100,2)))
    ok=S.dropna(subset=["r21"]); r=ok.sample(20,random_state=SEED)
    lost=ok[ok.r21<=0].drop(r.index,errors="ignore").sample(5,random_state=SEED)
    picks[name]=pd.concat([r.assign(pick="random"),lost.assign(pick="passed_but_lost")])
SU=pd.DataFrame(summ); SU.to_csv("summary.csv",index=False)
# comparison cases
comp=[("ALDX","2021-11-18"),("AAPL","2022-09-01")]
need=set(t for v in picks.values() for t in v.ticker)|{c[0] for c in comp}
P=pq.read_table(PX,columns=["ticker","date","open","high","low","close"],filters=[("ticker","in",list(need)),("date","<=",HI)]).to_pandas()
P["ticker"]=P.ticker.astype(str); P=P.drop_duplicates(["ticker","date"]).sort_values(["ticker","date"])
G={k:g.reset_index(drop=True) for k,g in P.groupby("ticker")}
def chart(ax,tk,D,title):
    g=G[tk]; i=int(np.searchsorted(g.date.values,np.datetime64(D)))
    w=g.iloc[max(0,i-60):i+22]; xs=np.arange(len(w)); j=i-max(0,i-60)
    up=w.close>=w.open; ax.vlines(xs,w.low,w.high,color="k",lw=.5)
    ax.bar(xs,(w.close-w.open).abs().clip(lower=1e-9),bottom=np.minimum(w.open,w.close),color=np.where(up,"g","r"),width=.7)
    ax.axvline(j,color="b",ls="--",lw=1); ax.plot(j,g.open[i],"b^",ms=8)
    for h,c in zip(H,["orange","purple","m"]):
        if i+h<len(g) and j+h<len(w): ax.plot(j+h,g.open[i+h],"o",color=c,ms=6,label=f"exit {h}d")
    ax.set_title(title,fontsize=7); ax.tick_params(labelsize=5); ax.legend(fontsize=5,loc="upper left")
with PdfPages("CASEBOOK_PRACTICE_2020_24.pdf") as pdf:
    f=plt.figure(figsize=(8.5,11)); f.text(.05,.95,"CASEBOOK — PRACTICE ONLY 2020-24 (2025-26 sealed until Fri 2026-10-23 23:00 HKT)",fontsize=9,weight="bold")
    f.text(.05,.92,f"Entry open D, exit open D+h, net of 30bp/side, win=net>0. Seed {SEED}. Survivors-only universe (upward bias).\nR4 Q8 is a FADE: long-side numbers shown; a fade 'works' if mean/win% are BELOW chart-pass alone.",fontsize=7)
    f.text(.05,.05,SU.to_string(index=False),fontsize=6,family="monospace"); pdf.savefig(f); plt.close(f)
    f,ax=plt.subplots(2,1,figsize=(8.5,11))
    for a,(t,d) in zip(ax,comp):
        row=M[(M.ticker==t)&(M.date==d)]; inf="" if row.empty else " | A=%s Q5=%s Q7=%s Q8=%s r21=%.1f%%"%(bool(row.A.iloc[0]),row.sq5_big_red_recent.iloc[0],row.sq7_lowerbb_reclaim.iloc[0],row.sq8_above_last_red_high.iloc[0],row.r21.iloc[0]*100)
        chart(a,t,d,f"COMPARISON {t} {d}{inf}")
    pdf.savefig(f); plt.close(f)
    for name,pk in picks.items():
        pk.drop(columns=[c for c in pk.columns if c.startswith("x")]).to_csv(f"{name}_sample.csv",index=False)
        rows=list(pk.itertuples())
        for k in range(0,len(rows),6):
            f,ax=plt.subplots(3,2,figsize=(8.5,11)); f.suptitle(f"{name} — PRACTICE 2020-24",fontsize=9)
            for a,r in zip(ax.flat,rows[k:k+6]):
                chart(a,r.ticker,r.date,f"{r.ticker} {r.date.date()} [{r.pick}] Q5={r.sq5_big_red_recent} Q7={r.sq7_lowerbb_reclaim} Q8={r.sq8_above_last_red_high}\nnet5={r.r5*100:.1f}% net10={r.r10*100:.1f}% net21={r.r21*100:.1f}% -> {r.win21}")
            for a in ax.flat[len(rows[k:k+6]):]: a.axis("off")
            f.tight_layout(); pdf.savefig(f); plt.close(f)
print(SU.to_string())
